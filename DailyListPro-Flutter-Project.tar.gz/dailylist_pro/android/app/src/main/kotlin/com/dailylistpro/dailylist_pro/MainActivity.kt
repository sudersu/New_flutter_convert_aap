package com.dailylistpro.dailylist_pro

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
